def _C_RESET        =[0m

def _C_BOLD         =[1m
def _C_BOLD_OFF     =[21m

def _C_UNDERLINE    =[4m
def _C_UNDERLINE_OFF=[24m

def _C_BLINK        =[5m
def _C_BLINK_OFF    =[25m

def _C_REVERSE      =[7m
def _C_REVERSE_OFF  =[27m

def _C_HIDE         =[8m
def _C_HIDE_OFF     =[28m

def _C_BLACK        =[30m
def _C_RED          =[31m
def _C_GREEN        =[32m
def _C_YELLOW       =[33m
def _C_BLUE         =[34m
def _C_MAGENTA      =[35m
def _C_CYAN         =[36m
def _C_WHITE        =[37m
def _C_DEFAULT      =[39m

def _CB_BLACK       =[40m
def _CB_RED         =[41m
def _CB_GREEN       =[42m
def _CB_YELLOW      =[43m
def _CB_BLUE        =[44m
def _CB_MAGENTA     =[45m
def _CB_CYAN        =[46m
def _CB_WHITE       =[47m
def _CB_DEFAULT     =[49m

def _ESC            =
def _CLS            =[2J