set lin 300
set ver off
col OWNER format a10
col TRIGGER_BODY format a50 wrap
undefine table_name

SELECT OWNER, TABLE_NAME, TRIGGER_NAME, TRIGGER_TYPE, TRIGGER_BODY FROM ALL_TRIGGERS WHERE TABLE_NAME=UPPER('&table_name');
