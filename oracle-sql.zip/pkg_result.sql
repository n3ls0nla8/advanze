Enter value for source_name: cif$fatca

PACKAGE BODY CIF$FATCA AS
--  **********************************
--  * Private Global Types           *
--  **********************************

--  **********************************
--  * Private Global Constants       *
--  **********************************

--  ******************************************
--  * Private Global Variables Declarations  *
--  ******************************************

--  *****************************************
--  * Local Constants                       *
--  *****************************************

--  **********************
--  * Local   Functions  *
--  **********************

--  **********************
--  * Public  Functions  *
--  **********************

    PROCEDURE SPLIT_PHONE_NO (arg_phone_number IN VARCHAR2, out_country_code OUT NUMBER, out_area_code OUT NUMBER, out_main_number OUT NUMBER)
    IS
        lv_phone_number VARCHAR2(50) := arg_phone_number;
        lv_country_code NUMBER := NULL;
        lv_area_code    NUMBER := NULL;
        lv_main_number  NUMBER := NULL;
    BEGIN
        IF lv_phone_number IS NOT NULL THEN
            select
            case
            when instr(lv_phone_number, '-') > 0 then
                to_number(substr(lv_phone_number, 1, instr(lv_phone_number, '-')-1))
            else
                null
            end
            into lv_country_code
            from dual;

            select
            case
            when instr(lv_phone_number, '-') > 0 and instr(lv_phone_number, '-') <> instr(lv_phone_number, '-', -1) then
                to_number(substr(lv_phone_number, instr(lv_phone_number, '-')+1, instr(lv_phone_number, '-', -1)-instr(lv_phone_number, '-')-1))
            else
                null
            end
            into lv_area_code
            from dual;

            select
            to_number(substr(lv_phone_number, instr(lv_phone_number, '-', -1)+1))
            into lv_main_number
            from dual;
        END IF;
        out_country_code := lv_country_code;
        out_area_code    := lv_area_code;
        out_main_number  := lv_main_number;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END SPLIT_PHONE_NO;

    FUNCTION IS_US_NATIONALITY (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM PERSONS
        WHERE PER_CUSTOMER_ID = lv_customer_id
          AND NVL(PER_NATIONALITY, 'HK') = 'US';

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_NATIONALITY;

    FUNCTION IS_US_HOME_ADDRESS (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM PERSONS, ADDRESSES
        WHERE PER_CUSTOMER_ID = lv_customer_id
          AND PER_RESIDENTIAL_ADDR_ID = ADR_ID
          AND NVL(ADR_COUNTRY_CODE, 'HK') = 'US';

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_HOME_ADDRESS;

    FUNCTION IS_US_OFFICE_ADDRESS (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM CUSTOMERS, ADDRESSES
        WHERE CUS_CUSTOMER_ID = lv_customer_id
          AND CUS_OFFICE_ADDR_ID = ADR_ID
          AND NVL(ADR_COUNTRY_CODE, 'HK') = 'US';

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_OFFICE_ADDRESS;

    FUNCTION IS_US_CORR_ADDRESS (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM ACCOUNT_OWNERS, CURRENT_ACCOUNTS, ADDRESSES
        WHERE AO_CUSTOMER_ID = lv_customer_id
          AND AO_ACCOUNT_NO = CA_ACCOUNT_NO
          AND CA_CORRESPONDENCE_ADDR_ID = ADR_ID
          AND NVL(ADR_COUNTRY_CODE, 'HK') = 'US'
          AND CA_ACCOUNT_STATUS <> 'C';  -- 20141029

        IF lv_res = 'N' THEN
            SELECT DECODE(COUNT(1), 0, 'N', 'Y')
            INTO lv_res
            FROM ACCOUNT_OWNERS, SAVINGS_ACCOUNTS, ADDRESSES
            WHERE AO_CUSTOMER_ID = lv_customer_id
              AND AO_ACCOUNT_NO = SA_ACCOUNT_NO
              AND SA_CORRESPONDENCE_ADDR_ID = ADR_ID
              AND Nvl(ADR_COUNTRY_CODE, 'HK') = 'US'
              AND SA_ACCOUNT_STATUS <> 'C'; --20141029
        END IF;

        IF lv_res = 'N' THEN
            SELECT DECODE(COUNT(1), 0, 'N', 'Y')
            INTO lv_res
            FROM CUSTOMER_SIGNATURES, SIGNATURE_CARDS, ADDRESSES
            WHERE CSG_CUSTOMER_ID = lv_customer_id
              AND CSG_SIGNATURE_REF_NO = SC_SIGNATURE_REF_NO
              AND SC_CORRESPONDENCE_ADDR_ID = ADR_ID
              AND Nvl(ADR_COUNTRY_CODE, 'HK') = 'US';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_CORR_ADDRESS;

    FUNCTION IS_US_HOME_PHONE_NO (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id  NUMBER := arg_customer_id;
        lv_phone_number VARCHAR2(50) := NULL;
        lv_country_code NUMBER := NULL;
        lv_area_code    NUMBER := NULL;
        lv_main_number  NUMBER := NULL;
        lv_res          VARCHAR2(1) := 'N';
    BEGIN
        SELECT CUS_CONTACT_PHONE_NO
        INTO lv_phone_number
        FROM CUSTOMERS
        WHERE CUS_CUSTOMER_ID = lv_customer_id;

        SPLIT_PHONE_NO (lv_phone_number, lv_country_code, lv_area_code, lv_main_number);

        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM US_CALLING_CODES
        WHERE UCC_CALLING_COUNTRY_CODE = lv_country_code
          AND UCC_AREA_CODE = lv_area_code;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_HOME_PHONE_NO;

    FUNCTION IS_US_OFFICE_PHONE_NO (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id  NUMBER := arg_customer_id;
        lv_phone_number VARCHAR2(50) := NULL;
        lv_country_code NUMBER := NULL;
        lv_area_code    NUMBER := NULL;
        lv_main_number  NUMBER := NULL;
        lv_res          VARCHAR2(1) := 'N';
    BEGIN
        SELECT CUS_OFFICE_PHONE_NO
        INTO lv_phone_number
        FROM CUSTOMERS
        WHERE CUS_CUSTOMER_ID = lv_customer_id;

        SPLIT_PHONE_NO (lv_phone_number, lv_country_code, lv_area_code, lv_main_number);

        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM US_CALLING_CODES
        WHERE UCC_CALLING_COUNTRY_CODE = lv_country_code
          AND UCC_AREA_CODE = lv_area_code;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_OFFICE_PHONE_NO;

    FUNCTION IS_US_MOBILE_PHONE_NO (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id  NUMBER := arg_customer_id;
        lv_phone_number VARCHAR2(50) := NULL;
        lv_country_code NUMBER := NULL;
        lv_area_code    NUMBER := NULL;
        lv_main_number  NUMBER := NULL;
        lv_res          VARCHAR2(1) := 'N';
    BEGIN
        SELECT CCC_CHANNEL_DETAIL
        INTO lv_phone_number
        FROM CUSTOMER_CONTACT_CHANNELS
        WHERE CCC_CUSTOMER_ID = lv_customer_id
          AND CCC_CHANNEL_TYPE = 'OVRSEA';

        SPLIT_PHONE_NO (lv_phone_number, lv_country_code, lv_area_code, lv_main_number);

        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM US_CALLING_CODES
        WHERE UCC_CALLING_COUNTRY_CODE = lv_country_code
          AND UCC_AREA_CODE = lv_area_code;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_MOBILE_PHONE_NO;

    FUNCTION IS_US_PERSON (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_customer_type VARCHAR2(1) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CUS_CUSTOMER_TYPE
        INTO lv_customer_type
        FROM CUSTOMERS
        WHERE CUS_CUSTOMER_ID = lv_customer_id;

        IF IS_US_NATIONALITY (lv_customer_id) = 'Y'
            OR (lv_customer_type = 'P' AND IS_US_HOME_ADDRESS (lv_customer_id) = 'Y')
            OR (lv_customer_type = 'C' AND IS_US_OFFICE_ADDRESS (lv_customer_id) = 'Y')
            OR IS_US_CORR_ADDRESS (lv_customer_id) = 'Y'
            OR IS_US_HOME_PHONE_NO (lv_customer_id) = 'Y'
            OR IS_US_OFFICE_PHONE_NO (lv_customer_id) = 'Y'
            OR IS_US_MOBILE_PHONE_NO (lv_customer_id) = 'Y'
        THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_US_PERSON;

    PROCEDURE UPDATE_US_PERSON (arg_customer_id IN NUMBER, arg_curr_proc_date IN DATE)
    IS
        lv_customer_id    NUMBER := arg_customer_id;
        lv_curr_proc_date DATE := arg_curr_proc_date;
        lv_cnt            NUMBER := 0;
        lv_us_person_ind  VARCHAR2(1) := '';
    BEGIN
        lv_us_person_ind := IS_US_PERSON (lv_customer_id);

        SELECT COUNT(1)
        INTO lv_cnt
        FROM CUSTOMER_CHARACTERISTICS
        WHERE CCR_CUSTOMER_ID = lv_customer_id
        AND CCR_CODE = 'USPERS';

        IF lv_cnt = 0 AND lv_us_person_ind = 'Y' THEN
            INSERT INTO CUSTOMER_CHARACTERISTICS (
                CCR_CUSTOMER_ID     ,
                CCR_CODE            ,
                CCR_VALUE           ,
                CCR_CHECKER_ID      ,
                CCR_LAST_UPDATE_DATE
            ) VALUES (
                lv_customer_id,
                'USPERS',
                lv_us_person_ind,
                'SYSTEM',
                TO_DATE(TO_CHAR(lv_curr_proc_date, 'YYYYMMDD')||TO_CHAR(SYSDATE, 'HH24:MI:SS'), 'YYYYMMDDHH24:MI:SS')
            );
        ELSIF (lv_cnt > 0) THEN
            UPDATE CUSTOMER_CHARACTERISTICS
            SET CCR_VALUE = lv_us_person_ind
              , CCR_CHECKER_ID = 'SYSTEM'
              , CCR_LAST_UPDATE_DATE = TO_DATE(TO_CHAR(lv_curr_proc_date, 'YYYYMMDD')||TO_CHAR(SYSDATE, 'HH24:MI:SS'), 'YYYYMMDDHH24:MI:SS')
            WHERE CCR_CUSTOMER_ID = lv_customer_id
              AND CCR_CODE = 'USPERS'
              AND CCR_VALUE <> lv_us_person_ind;
        END IF;
    END UPDATE_US_PERSON;

    FUNCTION IS_USPERS (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM CUSTOMER_CHARACTERISTICS
        WHERE CCR_CUSTOMER_ID = lv_customer_id
        AND CCR_CODE = 'USPERS'
        AND CCR_VALUE = 'Y';

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_USPERS;

--    FUNCTION HAS_US_JOINT_ACCOUNT_OWNER (arg_customer_id IN NUMBER)
--    RETURN VARCHAR2
--    IS
--        lv_customer_id NUMBER := arg_customer_id;
--        lv_res         VARCHAR2(1) := 'N';
--
--        CURSOR GET_CUSTOMERS (customer_id NUMBER)
--        IS
--            SELECT DISTINCT AO2.AO_CUSTOMER_ID CUS_ID
--            FROM ACCOUNT_OWNERS AO1, ACCOUNT_OWNERS AO2, ACCOUNTS
--            WHERE AO1.AO_CUSTOMER_ID = customer_id
--              AND AO1.AO_ACCOUNT_NO = AC_ACCOUNT_NO
--              AND Nvl(AC_ACCOUNT_STATUS, 'O') <> 'C'
--              AND AO1.AO_ACCOUNT_NO = AO2.AO_ACCOUNT_NO
--              AND AO2.AO_CUSTOMER_ID <> customer_id;
--    BEGIN
--        FOR REC IN GET_CUSTOMERS (lv_customer_id)
--        LOOP
--            IF IS_USPERS (REC.CUS_ID) = 'Y' THEN
--                lv_res := 'Y';
--                EXIT;
--            END IF;
--        END LOOP;
--
--        RETURN lv_res;
--    END HAS_US_JOINT_ACCOUNT_OWNER;

    FUNCTION HAS_US_AUTH_SIGNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_CUSTOMERS (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
                 , CUS_CUSTOMER_TYPE CUS_TYPE
              FROM CUSTOMER_RELATIONS, CUSTOMERS
             WHERE CR_RELATION_TYPE = '26'
               AND CR_CUSTOMER_ID = customer_id
               AND CR_RELATED_CUSTOMER_ID = CUS_CUSTOMER_ID;
    BEGIN

        FOR REC IN GET_CUSTOMERS (lv_customer_id)
        LOOP
            IF (REC.CUS_TYPE = 'P' AND IS_US_HOME_ADDRESS (REC.CUS_ID) = 'Y' OR IS_US_OFFICE_ADDRESS (REC.CUS_ID) = 'Y')
                OR (REC.CUS_TYPE = 'C' AND IS_US_OFFICE_ADDRESS (REC.CUS_ID) = 'Y')
                OR IS_US_CORR_ADDRESS (REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_AUTH_SIGNER;

    /* 20141029 */
    FUNCTION HAS_US_INCORP (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_COMPANIES (customer_id NUMBER)
        IS
            SELECT CO_CUSTOMER_ID CUS_ID
                 , CO_PLACE_OF_INCORP INCORP
              FROM COMPANIES, CUSTOMERS
             WHERE CO_CUSTOMER_ID = customer_id
               AND CO_CUSTOMER_ID = CUS_CUSTOMER_ID
               AND CUS_CUSTOMER_TYPE = 'C' ;
    BEGIN

        FOR REC IN GET_COMPANIES (lv_customer_id)
        LOOP
            IF  REC.INCORP = 'US' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_INCORP;


    /* 20141029 */
    FUNCTION HAS_DEPOSIT_AC (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

    BEGIN

        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM ACCOUNT_OWNERS, CURRENT_ACCOUNTS
        WHERE AO_CUSTOMER_ID = lv_customer_id
          AND AO_ACCOUNT_NO = CA_ACCOUNT_NO
          AND CA_ACCOUNT_STATUS <> 'C';

        IF lv_res = 'N' THEN
            SELECT DECODE(COUNT(1), 0, 'N', 'Y')
            INTO lv_res
            FROM ACCOUNT_OWNERS, SAVINGS_ACCOUNTS
            WHERE AO_CUSTOMER_ID = lv_customer_id
              AND AO_ACCOUNT_NO = SA_ACCOUNT_NO
              AND SA_ACCOUNT_STATUS <> 'C';
        END IF;

        RETURN lv_res;
    END HAS_DEPOSIT_AC;

     /* 20141029 */
    FUNCTION HAS_US_SHAREHOLDER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_SHAREHOLDER (customer_id NUMBER)
        IS
            SELECT CR_PERCENT_OF_SHARE PERCENT_OF_SHARE,
                   CR_RELATED_CUSTOMER_ID SHAREHOLDER
              FROM CUSTOMER_RELATIONS, CUST_FATCA_DETAILS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATED_CUSTOMER_ID = CFD_CUSTOMER_ID
               AND CFD_FATCA_TYPE <> 'W9P'
               AND CR_RELATION_TYPE = '02';
    BEGIN

        FOR REC IN GET_SHAREHOLDER (lv_customer_id)
        LOOP
            IF  REC.PERCENT_OF_SHARE >= 25 and IS_US_NATIONALITY(REC.SHAREHOLDER) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_SHAREHOLDER;

         /* 20141029 */
    FUNCTION HAS_US_CORR_ADDRESS_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_CORR_ADDRESS(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_CORR_ADDRESS_OWNER;

             /* 20141029 */
    FUNCTION HAS_US_HOME_ADDRESS_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_HOME_ADDRESS(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_HOME_ADDRESS_OWNER;

                 /* 20141029 */
    FUNCTION HAS_US_NATIONALITY_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_NATIONALITY(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_NATIONALITY_OWNER;

                     /* 20141029 */
    FUNCTION HAS_US_HOME_PHONE_NO_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_HOME_PHONE_NO(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_HOME_PHONE_NO_OWNER;

                         /* 20141029 */
    FUNCTION HAS_US_MOBILE_PHONE_NO_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_MOBILE_PHONE_NO(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_MOBILE_PHONE_NO_OWNER;

                             /* 20141029 */
    FUNCTION HAS_US_OFFICE_PHONE_NO_OWNER (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CR_RELATED_CUSTOMER_ID CUS_ID
              FROM CUSTOMER_RELATIONS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATION_TYPE = '08';
    BEGIN

        FOR REC IN GET_OWNER (lv_customer_id)
        LOOP
            IF  IS_US_OFFICE_PHONE_NO(REC.CUS_ID) = 'Y' THEN
                lv_res := 'Y';
                EXIT;
            END IF;
        END LOOP;

        RETURN lv_res;
    END HAS_US_OFFICE_PHONE_NO_OWNER;

    /* 20141029 */
    FUNCTION HAS_MISMATCH_FATCA_FIELD (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(1) := 'N';
        lv_count       NUMBER := 0;

        w8_form_sign_date CUST_FATCA_DETAILS.CFD_CONSENT_SIGN_DATE%type;
        ssn CUST_FATCA_DETAILS.CFD_SOCIAL_SECURITY_NO%type;
        ein CUST_FATCA_DETAILS.CFD_EMPLOYER_ID_NO%type;
        w9_form_sign_date CUST_FATCA_DETAILS.CFD_FORM_SIGN_DATE%type;
        w9_report_exemption_ind CUST_FATCA_DETAILS.CFD_REPORT_EXEMPTION_IND%type;
        w9_report_exemption_code CUST_FATCA_DETAILS.CFD_REPORT_EXEMPTION_CODE%type;

        owner_w8_form_sign_date CUST_FATCA_DETAILS.CFD_CONSENT_SIGN_DATE%type;
        owner_ssn CUST_FATCA_DETAILS.CFD_SOCIAL_SECURITY_NO%type;
        owner_ein CUST_FATCA_DETAILS.CFD_EMPLOYER_ID_NO%type;
        owner_w9_form_sign_date CUST_FATCA_DETAILS.CFD_FORM_SIGN_DATE%type;
        owner_w9_report_exemption_ind CUST_FATCA_DETAILS.CFD_REPORT_EXEMPTION_IND%type;
        owner_w9_report_exemption_code CUST_FATCA_DETAILS.CFD_REPORT_EXEMPTION_CODE%type;

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT CFD_CONSENT_SIGN_DATE W8_FORM_SIGN_DATE,
                   CFD_SOCIAL_SECURITY_NO SSN,
                   CFD_EMPLOYER_ID_NO EIN,
                   CFD_FORM_SIGN_DATE W9_FORM_SIGN_DATE,
                   CFD_REPORT_EXEMPTION_IND  W9_REPORT_EXEMPTION_IND,
                   CFD_REPORT_EXEMPTION_CODE W9_REPORT_EXEMPTION_CODE
              FROM CUSTOMER_RELATIONS, CUST_FATCA_DETAILS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATED_CUSTOMER_ID = CFD_CUSTOMER_ID
               AND CR_RELATION_TYPE = '08';
    BEGIN

       SELECT CFD_CONSENT_SIGN_DATE W8_FORM_SIGN_DATE,
              CFD_SOCIAL_SECURITY_NO SSN,
              CFD_EMPLOYER_ID_NO EIN,
              CFD_FORM_SIGN_DATE W9_FORM_SIGN_DATE,
              CFD_REPORT_EXEMPTION_IND  W9_REPORT_EXEMPTION_IND,
              CFD_REPORT_EXEMPTION_CODE W9_REPORT_EXEMPTION_CODE
         INTO w8_form_sign_date,
              ssn,
              ein,
              w9_form_sign_date,
              w9_report_exemption_ind,
              w9_report_exemption_code
         FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        open GET_OWNER(lv_customer_id);
        LOOP
              fetch GET_OWNER into owner_w8_form_sign_date,owner_ssn,owner_ein,owner_w9_form_sign_date,owner_w9_report_exemption_ind,owner_w9_report_exemption_code;

              if GET_OWNER%notfound then
                 if lv_count = 0 then
                    lv_res := 'Y';
                 else
                    lv_res := 'N';
                 end if;
                 EXIT;
              else
                 lv_count := lv_count + 1;
                 IF  nvl(to_char(w8_form_sign_date,'YYYYMMDD'),0) <> nvl(to_char(owner_w8_form_sign_date,'YYYYMMDD'),0)
                 OR  nvl(ssn,0) <> nvl(owner_ssn,0)
                 OR  nvl(ein,0) <> nvl(owner_ein,0)
                 OR  nvl(to_char(w9_form_sign_date,'YYYYMMDD'),0) <> nvl(to_char(owner_w9_form_sign_date,'YYYYMMDD'),0)
                 OR  nvl(w9_report_exemption_ind,0) <> nvl(owner_w9_report_exemption_ind,0)
                 OR  nvl(W9_REPORT_EXEMPTION_CODE,0) <> nvl(owner_w9_report_exemption_code,0) THEN
                     lv_res := 'Y';
                 EXIT;
                 END IF;
              end if;
        END LOOP;
        close GET_OWNER;

        lv_count := 0;

        SELECT COUNT(*)
        INTO   lv_count
        FROM   CUSTOMER_RELATIONS
        WHERE  CR_CUSTOMER_ID = lv_customer_id
        AND CR_RELATION_TYPE = '08';

        IF lv_count = 0 THEN
           lv_res := 'N';
        END IF;

        RETURN lv_res;

    END HAS_MISMATCH_FATCA_FIELD;

        /* 20141029 */
    FUNCTION HAS_MISMATCH_FATCA_TYPE (arg_customer_id IN NUMBER, arg_fatca_type IN VARCHAR2)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type VARCHAR2(3) := substr(arg_fatca_type,1,3);
        lv_res         VARCHAR2(1) := 'N';
        lv_count       NUMBER := 0;

        fatca_type   VARCHAR2(2);

        CURSOR GET_OWNER (customer_id NUMBER)
        IS
            SELECT nvl(substr(CFD_FATCA_TYPE,1,2),0) FATCA_TYPE
              FROM CUSTOMER_RELATIONS, CUST_FATCA_DETAILS
             WHERE CR_CUSTOMER_ID = customer_id
               AND CR_RELATED_CUSTOMER_ID = CFD_CUSTOMER_ID
               AND CR_RELATION_TYPE = '08';
    BEGIN

        open GET_OWNER(lv_customer_id);
        LOOP
              fetch GET_OWNER into fatca_type;

              if GET_OWNER%notfound then
                 if lv_count = 0 then
                    lv_res := 'Y';
                 else
                    lv_res := 'N';
                 end if;
                 EXIT;
              else
                 lv_count := lv_count + 1;
                 IF  fatca_type <> nvl(substr(lv_fatca_type,1,2),0) THEN
                     lv_res := 'Y';
                 EXIT;
                 END IF;
              end if;
        END LOOP;
        close GET_OWNER;

        lv_count := 0;

        SELECT COUNT(*)
        INTO   lv_count
        FROM   CUSTOMER_RELATIONS
        WHERE  CR_CUSTOMER_ID = lv_customer_id
        AND CR_RELATION_TYPE = '08';

        IF lv_count = 0 THEN
           lv_res := 'N';
        END IF;

        RETURN lv_res;

    END HAS_MISMATCH_FATCA_TYPE;


    FUNCTION IS_NFP_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'NFP'
            AND (IS_USPERS (lv_customer_id) = 'Y'
            OR HAS_US_AUTH_SIGNER (lv_customer_id) = 'Y') THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_NFP_EXCEPTION;

    FUNCTION IS_W8P_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'W8P' AND IS_US_NATIONALITY (lv_customer_id) = 'Y' AND HAS_DEPOSIT_AC(lv_customer_id) = 'Y' THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_W8P_EXCEPTION;

    FUNCTION IS_EXP_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'EXP'  AND HAS_DEPOSIT_AC(lv_customer_id) = 'Y' THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_EXP_EXCEPTION;

    FUNCTION IS_NCP_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'NCP' AND HAS_DEPOSIT_AC(lv_customer_id) = 'Y'  THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_NCP_EXCEPTION;

    /* 20141029 START */
    FUNCTION IS_NFC_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_company_type VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE, CFD_COMPANY_TYPE
        INTO lv_fatca_type, lv_company_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'NFC' and lv_company_type = 'SOP'   -- SOP
            AND (HAS_US_INCORP (lv_customer_id) = 'Y'
                OR IS_US_OFFICE_ADDRESS (lv_customer_id) = 'Y'
                OR IS_US_CORR_ADDRESS (lv_customer_id) = 'Y'
                OR HAS_US_HOME_ADDRESS_OWNER(lv_customer_id) = 'Y'
                OR HAS_US_NATIONALITY_OWNER(lv_customer_id) = 'Y'
                OR HAS_US_OFFICE_PHONE_NO_OWNER(lv_customer_id) = 'Y'
                OR HAS_US_MOBILE_PHONE_NO_OWNER(lv_customer_id) = 'Y'
                OR HAS_US_CORR_ADDRESS_OWNER (lv_customer_id) = 'Y'
                OR HAS_US_HOME_PHONE_NO_OWNER(lv_customer_id) = 'Y'
                OR HAS_US_AUTH_SIGNER (lv_customer_id) = 'Y'
                OR HAS_MISMATCH_FATCA_FIELD(lv_customer_id) = 'Y'
                OR HAS_MISMATCH_FATCA_TYPE (lv_customer_id, 'NFC') = 'Y') THEN
            lv_res := 'Y';
        ELSIF lv_fatca_type = 'NFC'  -- NON SOP
           AND (HAS_US_INCORP (lv_customer_id) = 'Y'
                OR IS_US_OFFICE_ADDRESS (lv_customer_id) = 'Y'
                OR IS_US_CORR_ADDRESS (lv_customer_id) = 'Y') THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_NFC_EXCEPTION;

    FUNCTION IS_W8C_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_company_type VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE, CFD_COMPANY_TYPE
        INTO lv_fatca_type, lv_company_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'W8C' AND lv_company_type = 'PNF' AND HAS_US_SHAREHOLDER(lv_customer_id) = 'Y' THEN  -- CHECK PNF
            lv_res := 'Y';
        END IF;

        IF lv_fatca_type = 'W8C' AND lv_company_type = 'SOP' AND (HAS_US_NATIONALITY_OWNER (lv_customer_id) = 'Y' OR HAS_US_AUTH_SIGNER (lv_customer_id) = 'Y'
        OR  HAS_MISMATCH_FATCA_FIELD(lv_customer_id) = 'Y' OR HAS_MISMATCH_FATCA_TYPE (lv_customer_id, 'W8C') = 'Y') THEN  -- CHECK SOP
            lv_res := 'Y';
        END IF;

        IF lv_fatca_type = 'W8C' AND HAS_US_INCORP(lv_customer_id) = 'Y' THEN  -- CHECK NON PNF and SOP
           lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_W8C_EXCEPTION;

    FUNCTION IS_EXC_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'EXC' THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_EXC_EXCEPTION;

    FUNCTION IS_NCC_EXCEPTION (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_fatca_type  VARCHAR2(3) := '';
        lv_res         VARCHAR2(1) := 'N';
    BEGIN
        SELECT CFD_FATCA_TYPE
        INTO lv_fatca_type
        FROM CUST_FATCA_DETAILS
        WHERE CFD_CUSTOMER_ID = lv_customer_id;

        IF lv_fatca_type = 'NCC' THEN
            lv_res := 'Y';
        END IF;

        RETURN lv_res;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN lv_res;
    END IS_NCC_EXCEPTION;

    /* 20141029 END */

    PROCEDURE UPDATE_EXCEPTION (arg_customer_id IN NUMBER, arg_fatca_type IN VARCHAR2, arg_curr_proc_date IN DATE)
    IS
        lv_customer_id    NUMBER := arg_customer_id;
        lv_fatca_type     VARCHAR2(3) := substr(arg_fatca_type, 1, 3);
        lv_curr_proc_date DATE := arg_curr_proc_date;

        lv_cnt NUMBER := 0;
    BEGIN
        SELECT COUNT(1)
        INTO lv_cnt
        FROM CUST_FATCA_EXCEPTIONS
        WHERE CFE_CUSTOMER_ID = lv_customer_id;

        IF lv_cnt = 0 THEN
            INSERT INTO CUST_FATCA_EXCEPTIONS (
                CFE_CUSTOMER_ID,
                CFE_FATCA_TYPE,
                CFE_LAST_EXCEPTION_DATE
            ) VALUES (
                lv_customer_id,
                lv_fatca_type,
                lv_curr_proc_date
            );
        ELSE
            UPDATE CUST_FATCA_EXCEPTIONS
            SET CFE_FATCA_TYPE = lv_fatca_type
              /*, CFE_LAST_EXCEPTION_DATE = lv_curr_proc_date   12AUG2014*/
            WHERE CFE_CUSTOMER_ID = lv_customer_id
              AND CFE_FATCA_TYPE <> lv_fatca_type;
        END IF;
    END UPDATE_EXCEPTION;


    PROCEDURE DELETE_EXCEPTION (arg_customer_id IN NUMBER)
    IS
        lv_customer_id NUMBER := arg_customer_id;
    BEGIN
        DELETE FROM CUST_FATCA_EXCEPTION_DETAILS
        WHERE CFED_CUSTOMER_ID = lv_customer_id;

        DELETE FROM CUST_FATCA_EXCEPTIONS
        WHERE CFE_CUSTOMER_ID = lv_customer_id;
    END DELETE_EXCEPTION;
--
--
-- Added 18-SEP-2015
-- ***************************************************************************
-- Function Name   :   FATCA_PORTFOLIO_BALANCE
-- Description     :   This function is used to calculate the portfolio balance of the customer
--
-- Parameter       :   In     : arg_cus_id
--                     Out    : out_port_bal (-1 for error)
-- ***************************************************************************
    function FATCA_PORTFOLIO_BALANCE (   arg_cus_id          in  number)         /* Customer ID */
    return number is
        out_port_bal number := 0;
    begin
        if arg_cus_id is null then
            out_port_bal := -1;
            return out_port_bal;
        end if;
        begin
            select SUM(RATED_BAL) into out_port_bal from(
                select  AO_CUSTOMER_ID CUS_ID, CAB_CURRENT_BALANCE * abc.rate     RATED_BAL
                from    CURRENT_ACCOUNT_BALANCES, CURRENT_ACCOUNTS, ACCOUNT_OWNERS
                , (select er_currency_code, max(er_bid_rate) rate, max(TRUNC(er_effective_timestamp))
                    from (select * from exchange_rates
                    where er_currency_exch_sub_type = 'TT' and er_exchange_rate_type = 'MEX')
                    group by er_currency_code) abc
                where   CAB_CURRENCY_CODE = abc.er_currency_code
                and     CA_ACCOUNT_NO = CAB_ACCOUNT_NO
                and     CAB_CURRENT_BALANCE >= 0
                and     CA_ACCOUNT_STATUS <> 'C'
                and     AO_ACCOUNT_NO = CA_ACCOUNT_NO
                and     AO_CUSTOMER_ID = arg_cus_id
                union all
                select  AO_CUSTOMER_ID CUS_ID, SAB_CURRENT_BALANCE * abc.rate     RATED_BAL
                from    SAVINGS_ACCOUNT_BALANCES, SAVINGS_ACCOUNTS, ACCOUNT_OWNERS
                , (select er_currency_code, max(er_bid_rate) rate, max(TRUNC(er_effective_timestamp))
                    from (select * from exchange_rates
                    where er_currency_exch_sub_type = 'TT' and er_exchange_rate_type = 'MEX')
                    group by er_currency_code) abc
                where  SAB_CURRENCY_CODE = abc.er_currency_code
                and    SA_ACCOUNT_NO = SAB_ACCOUNT_NO
                and    SAB_CURRENT_BALANCE >= 0
                and    SA_ACCOUNT_STATUS != 'C'
                and    SA_BRANCH_CODE != 980
                and    SAB_BALANCE_STATUS != 'C'
                and    SAB_CURRENCY_INT_SUB_TYPE != 'SFA'
                and    AO_ACCOUNT_NO = SA_ACCOUNT_NO
                and    AO_CUSTOMER_ID = arg_cus_id
                union all
                select  AO_CUSTOMER_ID CUS_ID, decode(sign(FDA_PRINCIPAL), -1, 0, FDA_PRINCIPAL) * abc.rate        RATED_BAL
                from    APP_INTEREST_USER_CCY_CODES, FXD_ACCOUNT_PARTICULARS, SIGNATURE_CARDS,
                        FIXED_DEPOSIT_ACCOUNTS, ACCOUNT_OWNERS
                , (select er_currency_code, max(er_bid_rate) rate, max(TRUNC(er_effective_timestamp))
                    from (select * from exchange_rates
                    where er_currency_exch_sub_type = 'TT' and er_exchange_rate_type = 'MEX')
                    group by er_currency_code) abc
                where FDA_CURRENCY_CODE = abc.er_currency_code
                and   FDA_SIGNATURE_REF_NO = SC_SIGNATURE_REF_NO
                and   APIC_CURRENCY_CODE = FDA_CURRENCY_CODE
                and   APIC_CURRENCY_INT_SUB_TYPE = FDA_CURRENCY_INT_SUB_TYPE
                and   FDA_ACCOUNT_NO = FDAP_ACCOUNT_NO (+)
                and   FDA_CURRENCY_INT_SUB_TYPE != 'LHF'
                and   FDA_PRINCIPAL != 0
                and   FDA_ACCOUNT_STATUS != 'C'
                and   AO_ACCOUNT_NO = FDA_ACCOUNT_NO
                and   AO_CUSTOMER_ID = arg_cus_id
                union all
                select AO_CUSTOMER_ID CUS_ID, SUM((NVL(SABA_BANK_SHARE_BALANCE,0)       +
                                                 NVL(SABA_CCASS_SHARE_BALANCE,0)      +
                                                 NVL(SABA_OTHERS_SHARE_BALANCE,0)     +
                                                 NVL(SABA_TRANSIT_C_SHARE_BALANCE,0)  +
                                                 NVL(SABA_TRANSIT_N_SHARE_BALANCE,0)) *
                                                 NVL(SCR_MARKET_PRICE,0)) RATED_BAL
                 FROM SECURITIES, SECURITIES_ACCOUNT_BALANCES, SECURITIES_ACCOUNTS, ACCOUNT_OWNERS
                 WHERE SABA_SECURITIES_CODE = SCR_SECURITIES_CODE(+)
                 AND SAC_ACCOUNT_NO       = SABA_ACCOUNT_NO(+)
                 AND AO_ACCOUNT_NO        = SAC_ACCOUNT_NO
                 AND SAC_ACCOUNT_STATUS   <> 'C'
                 AND AO_CUSTOMER_ID = arg_cus_id
                 group by AO_CUSTOMER_ID, AO_ACCOUNT_NO
                union all
                select AO_CUSTOMER_ID CUS_ID, ROUND(NVL(SUM(UTAB_CLOSING_BALANCE *
                                                          UTF_UNIT_PRICE *
                                                          abc.rate),
                                                      0),  2)            RATED_BAL
                 FROM   UNIT_TRUST_FUNDS, UNIT_TRUST_ACCOUNT_BALANCES, UNIT_TRUST_ACCOUNTS,  ACCOUNT_OWNERS
                 , (select er_currency_code, max(er_bid_rate) rate, max(TRUNC(er_effective_timestamp))
                    from (select * from exchange_rates
                    where er_currency_exch_sub_type = 'TT' and er_exchange_rate_type = 'MEX')
                    group by er_currency_code) abc
                 WHERE   UTA_ACCOUNT_NO = UTAB_ACCOUNT_NO
                 and    UTA_ACCOUNT_STATUS <> 'C'
                 and    UTAB_ACCOUNT_NO = AO_ACCOUNT_NO
                 AND    UTAB_FUND_CODE = UTF_FUND_CODE
                 AND    UTF_CURRENCY_CODE = abc.er_currency_code
                 AND    AO_CUSTOMER_ID = arg_cus_id
                 group by AO_CUSTOMER_ID, UTAB_ACCOUNT_NO
            );
            -- not found	-1
            exception
                when no_data_found then
                    out_port_bal := -1;
                    return out_port_bal;
        end;

        --OK
        return out_port_bal;

        -- sql error	-1
        exception
            when others then
                out_port_bal := -1;
                dbms_output.put_line('Error customer id:[' || arg_cus_id || ']');
                dbms_output.put_line(SQLERRM);
                return out_port_bal;
     end FATCA_PORTFOLIO_BALANCE;
--
--
-- Added 18-SEP-2015
-- ***************************************************************************
-- Function Name   :   GET_USD_1M_TO_HKD
-- Description     :   This function is used to calculate the most updated 1M USD to HKD
--
-- Parameter       :   In     :
--                     Out    : out_port_bal (-1 for error)
-- ***************************************************************************
    function GET_USD_1M_TO_HKD
    return number is
        out_1M number := 0;
    begin
        begin
            select 1000000 * abc.rate into out_1M
            from  (select er_currency_code, max(er_bid_rate) rate, max(TRUNC(er_effective_timestamp))
                from (select * from exchange_rates
                where er_currency_exch_sub_type = 'TT' and er_exchange_rate_type = 'MEX')
                group by er_currency_code) abc
            where abc.er_currency_code = 'USD';
            return out_1M;
            -- not found	-1
            exception
                when no_data_found then
                    out_1M := -1;
                    return out_1M;
        end;
     end GET_USD_1M_TO_HKD;
--
--
-- Added 22-SEP-2015
-- ***************************************************************************
-- Function Name   :   HAS_WMA_UTA
-- Description     :   This function is used to check whether the customer has WMA/UTA accounts
--
-- Parameter       :   In     : arg_customer_id
--                     Out    : out_port_bal (-1 for error)
-- ***************************************************************************
    FUNCTION HAS_WMA_UTA (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(7) := 'N';

    BEGIN

        SELECT DECODE(COUNT(1), 0, 'N', 'Y')
        INTO lv_res
        FROM ACCOUNT_OWNERS, UNIT_TRUST_ACCOUNTS
        WHERE AO_CUSTOMER_ID = lv_customer_id
          AND AO_ACCOUNT_NO = UTA_ACCOUNT_NO
          AND UTA_ACCOUNT_STATUS <> 'C';

        IF lv_res = 'Y' THEN
          --SELECT decode(UTA_ACCOUNT_SUB_TYPE, 'WM', 'W', 'U')
          select DECODE(COUNT(1), 0, 'UTA', 'WMA')
          INTO lv_res
          FROM ACCOUNT_OWNERS, UNIT_TRUST_ACCOUNTS
          WHERE AO_CUSTOMER_ID = lv_customer_id
          AND AO_ACCOUNT_NO = UTA_ACCOUNT_NO
          AND UTA_ACCOUNT_SUB_TYPE = 'WM'
          AND UTA_ACCOUNT_STATUS <> 'C';

          if lv_res = 'WMA' then
             select DECODE(COUNT(1), 0, 'WMA', 'UTA/WMA')
             INTO lv_res
             FROM ACCOUNT_OWNERS, UNIT_TRUST_ACCOUNTS
             WHERE AO_CUSTOMER_ID = lv_customer_id
             AND AO_ACCOUNT_NO = UTA_ACCOUNT_NO
             AND UTA_ACCOUNT_SUB_TYPE = 'IN'
             AND UTA_ACCOUNT_STATUS <> 'C';
          end if;
        END IF;

        RETURN lv_res;
    END HAS_WMA_UTA;
--
--
-- Added 22-SEP-2015
-- ***************************************************************************
-- Function Name   :   HAS_WMA_UTA
-- Description     :   This function is used to check whether the customer has WMA/UTA accounts
--
-- Parameter       :   In     : arg_customer_id
--                     Out    : lv_res
-- ***************************************************************************
    FUNCTION CONCAT_CORR_ADDR (arg_customer_id IN NUMBER)
    RETURN VARCHAR2
    IS
        lv_customer_id NUMBER := arg_customer_id;
        lv_res         VARCHAR2(400) := '';

        CURSOR GET_NON_HK_CTRY_CODE (customer_id NUMBER)
        IS
        select distinct ADR_COUNTRY_CODE ADDR from addresses where ADR_ID in (
            select CA_CORRESPONDENCE_ADDR_ID ADDR_ID from CURRENT_ACCOUNTS, ACCOUNT_OWNERS where CA_ACCOUNT_NO = AO_ACCOUNT_NO and AO_CUSTOMER_ID = lv_customer_id UNION
            select SA_CORRESPONDENCE_ADDR_ID ADDR_ID from SAVINGS_ACCOUNTS, ACCOUNT_OWNERS where SA_ACCOUNT_NO = AO_ACCOUNT_NO and AO_CUSTOMER_ID = lv_customer_id UNION
            select FDA_CORRESPONDENCE_ADDR_ID ADDR_ID from FIXED_DEPOSIT_ACCOUNTS, ACCOUNT_OWNERS where FDA_ACCOUNT_NO = AO_ACCOUNT_NO and AO_CUSTOMER_ID = lv_customer_id UNION
            select SAC_CORRESPONDENCE_ADDR_ID ADDR_ID from SECURITIES_ACCOUNTS, ACCOUNT_OWNERS where SAC_ACCOUNT_NO = AO_ACCOUNT_NO and AO_CUSTOMER_ID = lv_customer_id UNION
            select UTA_CORRESPONDENCE_ADDR_ID ADDR_ID from UNIT_TRUST_ACCOUNTS, ACCOUNT_OWNERS where UTA_ACCOUNT_NO = AO_ACCOUNT_NO and AO_CUSTOMER_ID = lv_customer_id );
    BEGIN

        FOR REC IN GET_NON_HK_CTRY_CODE (lv_customer_id)
        LOOP
            IF  (REC.ADDR) != 'HK' THEN
                lv_res := lv_res || REC.ADDR || ', ';
            END IF;
        END LOOP;

        lv_res  :=  RTRIM(LTRIM(lv_res,' ,'),' ,');

        RETURN lv_res;
    END CONCAT_CORR_ADDR;
END CIF$FATCA;
