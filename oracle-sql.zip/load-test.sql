set serveroutput on
declare
    AC_INFO       varchar2(1000) := '';
    CUST_INFO     varchar2(4000) := '';
    SA_INFO       varchar2(1000) := '';
    DA_INFO       varchar2(1000) := '';
    start_ts         TIMESTAMP;
    end_ts           TIMESTAMP;
begin
    start_ts := current_timestamp;
    for rec in (select  distinct UTA_ACCOUNT_NO         ACCOUNT_NO from    UNIT_TRUST_ACCOUNTS) loop
        CIF$WMS.GET_AC_DETAIL(rec.account_no, AC_INFO, CUST_INFO, SA_INFO, DA_INFO);
    end loop;
    end_ts := current_timestamp;
    dbms_output.put_line('Start: ' || start_ts);
    dbms_output.put_line('End: ' || end_ts);
    dbms_output.put_line('Time elapsed: ' || (end_ts - start_ts));
end;
/
