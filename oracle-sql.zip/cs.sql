set lin 300
set ver off
col OWNER format a10 wrap
col TYPE format a4 wrap
col CONSTRAINT_NAME format a30 wrap
col TABLE_NAME format a25 wrap
col COLUMN_NAME format a20 wrap
col SEARCH_CONDITION format a60 wrap
col INDEX_OWNER format a10 wrap
col INDEX_NAME format a20 wrap
undefine table_name

SELECT a.OWNER, a.CONSTRAINT_NAME, a.CONSTRAINT_TYPE TYPE, a.TABLE_NAME, c.COLUMN_NAME, a.SEARCH_CONDITION, a.INDEX_OWNER, a.INDEX_NAME
from ALL_CONSTRAINTS a 
join ALL_CONS_COLUMNS c on c.CONSTRAINT_NAME=a.CONSTRAINT_NAME and a.TABLE_NAME=UPPER('&&table_name');
