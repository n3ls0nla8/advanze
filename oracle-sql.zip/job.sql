set lin 32767
set trims on
set ver off
set echo off

undefine jobId
define jobId=&jobId

select 
upper('&jobId') JOB_ID_PREFIX,
(select count(*) from TAS_APPLICATION_PROGRAMS where TAAP_PROGRAM_ID like upper('&jobId%')) PROGRAMS,
(select count(*) from TAS_REPORTS where TARP_REPORT_ID like upper('&jobId%')) ORACLE_REPORTS,
(select count(*) from TAS_EXECUTION_STEP_STATUS where TASS_PROGRAM_ID like upper('&jobId%')) STEPS,
(select count(*) from TAS_JOBS_RUNNING where TAJR_PROGRAM_ID like upper('&jobId%')) JOBS
from dual;
col TAAP_APPL_CODE format a15
col TAAP_DESCRIPTION format a50 wrap
col TASS_COMPLETION_INDICATOR format a25 wrap
col TAJR_PROGRAM_ID format a25 wrap
select * from TAS_APPLICATION_PROGRAMS where TAAP_PROGRAM_ID like upper('&jobId%');
select * from TAS_REPORTS where TARP_REPORT_ID like upper('&jobId%');
select * from TAS_EXECUTION_STEP_STATUS where TASS_PROGRAM_ID like upper('&jobId%');
select * from TAS_JOBS_RUNNING where TAJR_PROGRAM_ID like upper('&jobId%');
