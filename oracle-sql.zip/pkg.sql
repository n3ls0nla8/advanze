set lin 5000
set pages 9999
set trims on
set ver off
set echo off
set head off
set feed off

undefine source_name
define source_name=&source_name

spo result.sql
set termout off 

SELECT TEXT FROM ALL_SOURCE WHERE NAME LIKE UPPER('&&source_name') AND TYPE='PACKAGE' ORDER BY LINE;
SELECT TEXT FROM ALL_SOURCE WHERE NAME LIKE UPPER('&&source_name') AND TYPE='PACKAGE BODY' ORDER BY LINE;
spo off