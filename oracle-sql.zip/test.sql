declare

l_x number :=0;
l_y number :=0;
l_g number :=0;
l_h number :=0;

out_ac_info varchar2(20) := '';
out_cust_info varchar2(20) := '';
out_sa_info varchar2(20) := '';
out_da_info varchar2(20) := '';

function GET_CR_RATE(in_a varchar2) return number as
o_b number;
BEGIN

if in_a ='A' then
  select 1 into o_b from dual;
else
  select 2 into o_b from dual;
end if;
return o_b;
END GET_CR_RATE;

begin
-- l_x := GET_CR_RATE('B');
-- dbms_output.put_line('l_x is ['|| l_x ||']');
-- dbms_output.put_line('l_y is ['|| l_y ||']');

-- select GET_CR_RATE('B') into l_g from dual;
-- dbms_output.put_line('l_g is ['|| l_g ||']');
-- dbms_output.put_line('l_h is ['|| l_h ||']');

 CIF$WMS.GET_AC_DETAIL(10251100416770, out_ac_info, out_cust_info, out_sa_info, out_da_info);

end;
/
