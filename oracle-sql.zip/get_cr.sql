set echo off
set ver off
set serverout on

undefine customer_id

declare
        total number := 0;
    db_customer_id number := &customer_id;
    FUNCTION ROUND5(arg in NUMBER) return NUMBER AS
        a VARCHAR2(20) := to_char(arg, '999999999990.0000');
        b number := to_number(substr(a, length(a)-1, 1));
        ret number := arg;
    BEGIN
        if b > 5 then
            ret := arg + .01;
        end if;
        ret := trunc(ret, 2);
        return ret;
    END ROUND5;
    BEGIN
        for rec in (SELECT DECODE(SUBSTR(account_no, 0, 2), '30',
            (SELECT DECODE(FDA_CURRENCY_INT_SUB_TYPE, 'SWAP', TO_CHAR(FDA_SPOT_RATE, '9999.9999'), rate)
            FROM FIXED_DEPOSIT_ACCOUNTS,
              APP_INTEREST_USER_CCY_CODES
            WHERE FDA_ACCOUNT_NO          = to_number(account_no)
            AND FDA_CURRENCY_INT_SUB_TYPE = APIC_CURRENCY_INT_SUB_TYPE
            AND FDA_CURRENCY_CODE         = APIC_CURRENCY_CODE
            AND APIC_CURRENCY_REF_CODE    = currency_code
            ), rate) * bal amt
            FROM
            (SELECT DECODE(SUBSTR(account_no, 0, 2), '40', APP$EXCHRATE.GET_LAB_EXCH_RATE_R (currency_code, to_date(APP$BSNDT.GET_CURR_PROC_DATE, 'DDMMYYYY')),
              (SELECT TO_CHAR(ER_BID_RATE, '9999.9999')
              FROM EXCHANGE_RATES,
                APP_INTEREST_USER_CCY_CODES
              WHERE ER_CURRENCY_EXCH_SUB_TYPE = 'TT'
              AND ER_EXCHANGE_RATE_TYPE       = 'MEX'
              AND ER_CURRENCY_CODE            = APIC_CURRENCY_CODE
              AND APIC_CURRENCY_REF_CODE      = currency_code
              ) ) rate,
              currency_code,
              account_no,
              bal
            FROM
              (SELECT CAB_CURRENCY_CODE currency_code,
                TO_CHAR(AO_ACCOUNT_NO) account_no,
                TO_CHAR(NVL(CAB_CURRENT_BALANCE,0), '999999999990.99') bal
              FROM ACCOUNT_OWNERS,
                CURRENT_ACCOUNT_BALANCES,
                CURRENT_ACCOUNTS,
                FACILITIES
              WHERE FAC_FACILITY_TYPE(+) = 'OD'
              AND CA_ACCOUNT_NO          = FAC_ACCOUNT_NO(+)
              AND AO_ACCOUNT_NO          = CAB_ACCOUNT_NO
              AND CA_ACCOUNT_STATUS     <> 'C'
              AND CA_ACCOUNT_NO          = AO_ACCOUNT_NO
              AND AO_CUSTOMER_ID         = to_number(db_customer_id)
              UNION ALL
              SELECT APIC_CURRENCY_REF_CODE,
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(NVL(IRDB_DEPOSIT_BALANCE,0) + NVL(IRDB_CALLED_BALANCE,0), '999999999990.99')
              FROM ACCOUNT_OWNERS,
                IRD_ACCOUNTS,
                IRD_ACCOUNT_BALANCES,
                APP_INTEREST_USER_CCY_CODES
              WHERE IRDA_ACCOUNT_NO          = IRDB_ACCOUNT_NO
              AND IRDA_ACCOUNT_STATUS       <> 'C'
              AND IRDB_CURRENCY_CODE         = APIC_CURRENCY_CODE
              AND IRDB_CURRENCY_INT_SUB_TYPE = APIC_CURRENCY_INT_SUB_TYPE
              AND AO_ACCOUNT_NO              = IRDB_ACCOUNT_NO
              AND AO_CUSTOMER_ID             = to_number(db_customer_id)
              UNION ALL
              SELECT APIC_CURRENCY_REF_CODE,
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(NVL(SAB_CURRENT_BALANCE,0), '999999999990.99')
              FROM ACCOUNT_OWNERS,
                SAVINGS_ACCOUNT_BALANCES,
                SAVINGS_ACCOUNTS,
                APP_INTEREST_USER_CCY_CODES
              WHERE SAB_CURRENCY_CODE       = APIC_CURRENCY_CODE
              AND SAB_CURRENCY_INT_SUB_TYPE = APIC_CURRENCY_INT_SUB_TYPE
              AND SAB_BALANCE_STATUS       <> 'C'
              AND SA_ACCOUNT_NO             = AO_ACCOUNT_NO
              AND AO_ACCOUNT_NO             = SAB_ACCOUNT_NO
              AND AO_CUSTOMER_ID            = to_number(db_customer_id)
              UNION ALL
              SELECT APIC_CURRENCY_REF_CODE,
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(NVL(FDA_PRINCIPAL,0), '999999999990.99')
              FROM ACCOUNT_OWNERS,
                FIXED_DEPOSIT_ACCOUNTS,
                SIGNATURE_CARDS,
                APP_INTEREST_USER_CCY_CODES
              WHERE SC_STATUS              != 'C'
              AND FDA_CURRENCY_CODE         = APIC_CURRENCY_CODE
              AND FDA_CURRENCY_INT_SUB_TYPE = APIC_CURRENCY_INT_SUB_TYPE
              AND FDA_ACCOUNT_STATUS       <> 'C'
              AND SC_SIGNATURE_REF_NO       = FDA_SIGNATURE_REF_NO
              AND AO_ACCOUNT_NO             = FDA_ACCOUNT_NO
              AND AO_CUSTOMER_ID            = to_number(db_customer_id)
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9900000000 + CSG_SIGNATURE_REF_NO),
                TO_CHAR(0)
              FROM CUSTOMER_SIGNATURES,
                SIGNATURE_CARDS
              WHERE SC_STATUS        != 'C'
              AND SC_SIGNATURE_REF_NO = CSG_SIGNATURE_REF_NO
              AND CSG_CUSTOMER_ID     = to_number(db_customer_id)
              UNION ALL
              SELECT 'HKD',
                SUBSTR(ltrim(TO_CHAR(AO_ACCOUNT_NO)),1,16),
                TO_CHAR(SUM((NVL(SABA_BANK_SHARE_BALANCE,0) + NVL(SABA_CCASS_SHARE_BALANCE,0) + NVL(SABA_OTHERS_SHARE_BALANCE,0) + NVL(SABA_TRANSIT_C_SHARE_BALANCE,0) + NVL(SABA_TRANSIT_N_SHARE_BALANCE,0)) * NVL(SCR_MARKET_PRICE,0)), '999999999990.99')
              FROM SECURITIES,
                SECURITIES_ACCOUNT_BALANCES,
                SECURITIES_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE SABA_SECURITIES_CODE = SCR_SECURITIES_CODE(+)
              AND SAC_ACCOUNT_NO         = SABA_ACCOUNT_NO(+)
              AND AO_ACCOUNT_NO          = SAC_ACCOUNT_NO
              AND AO_CUSTOMER_ID         = to_number(db_customer_id)
              AND SAC_ACCOUNT_STATUS    <> 'C'
              GROUP BY AO_ACCOUNT_NO,
                5,
                8
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(0)
              FROM ACCOUNT_OWNERS,
                BILLS_ACCOUNTS
              WHERE BA_ACCOUNT_STATUS <> 'C'
              AND AO_ACCOUNT_NO        = BA_ACCOUNT_NO
              AND AO_ACCOUNT_NO BETWEEN 90e12 AND 91e12-1
              AND AO_CUSTOMER_ID = to_number(db_customer_id)
              UNION ALL
              SELECT LA_CURRENCY_CODE,
                SUBSTR(TO_CHAR(LA_ACCOUNT_NO),1,14),
                TO_CHAR(NVL(SUM(DECODE(SIGN(LP_DUE_DATE - APSP_PARAMETER_DATE_VALUE), 0, lp_paid_amt - TRUNC(lp_due_amt,2), 1, lp_paid_amt, lp_paid_amt - TRUNC(lp_due_amt,2))),0) - NVL(LA_REMAINING_PRINCIPAL,0) + NVL(SUM(DECODE(SIGN(LP_DUE_DATE - APSP_PARAMETER_DATE_VALUE), 0, DECODE(lp_loan_payment_type, '01', TRUNC(lp_due_amt,2) - TRUNC(lp_interest_accrual,2), 0), 0)),0) , '999999999990.99')
              FROM ACCOUNT_OWNERS,
                LOAN_ACCOUNTS,
                LOAN_PAYMENTS,
                APP_SYSTEM_PARAMETERS
              WHERE LP_LOAN_PAYMENT_TYPE IN ( '01', '02','07' )
              AND LA_ACCOUNT_NO           = LP_ACCOUNT_NO
              AND APSP_APPL_CODE          = 'TEL'
              AND APSP_PARAMETER_CODE     = 'CURR_BSNDT'
              AND LA_LOAN_TYPE           IN ('0', '1', '2', '3', '4')
              AND LA_ACCOUNT_STATUS      != 'C'
              AND (LA_ACCOUNT_NO          = AO_ACCOUNT_NO
              OR ( LA_ACCOUNT_NO BETWEEN AO_ACCOUNT_NO * 10000 AND AO_ACCOUNT_NO * 10000 + 9999
              AND LA_LOAN_TYPE   = '2') )
              AND AO_CUSTOMER_ID = to_number(db_customer_id)
              GROUP BY SUBSTR(TO_CHAR(LA_ACCOUNT_NO),1,14),
                LA_CURRENCY_CODE,
                LA_REMAINING_PRINCIPAL,
                LA_LOAN_TYPE
              UNION ALL
              SELECT LA_CURRENCY_CODE,
                SUBSTR(TO_CHAR(LA_ACCOUNT_NO),1,14),
                TO_CHAR(SUM(0 - NVL(LA_REMAINING_PRINCIPAL,0)))
              FROM LOAN_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE LA_LOAN_TYPE     = '2'
              AND LA_ACCOUNT_STATUS != 'C'
              AND (LA_ACCOUNT_NO     = AO_ACCOUNT_NO
              OR ( LA_ACCOUNT_NO BETWEEN AO_ACCOUNT_NO                   *10000 AND AO_ACCOUNT_NO *10000+9999) )
              AND (LA_purpose_of_loan, trim(SUBSTR(la_court_name,1,4))) IN
                (SELECT LNC_CATEGORY_CODE , LNC_CATEGORY_SUFFIX FROM loan_categories
                )
              AND ( (la_date_of_advance                IS NULL
              OR TO_CHAR(la_date_of_advance,'DDMMYYYY') = TO_CHAR(TRUNC(APP$BSNDT.GET_CURR_PROC_DATE),'DDMMYYYY'))
              AND LA_INSTALMENT_AMT                    IS NOT NULL )
              AND AO_CUSTOMER_ID                        = to_number(db_customer_id)
              GROUP BY SUBSTR(TO_CHAR(LA_ACCOUNT_NO),1,14),
                LA_CURRENCY_CODE,
                LA_REMAINING_PRINCIPAL,
                LA_LOAN_TYPE
              UNION ALL
              SELECT LA_CURRENCY_CODE,
                TO_CHAR(LA_ACCOUNT_NO),
                TO_CHAR(0,'999999999990.99')
              FROM LOAN_ACCOUNTS A,
                ACCOUNT_OWNERS,
                LOAN_CATEGORIES
              WHERE LNC_ALLOW_REVOLVING_FLAG = 'Y'
              AND LNC_CATEGORY_CODE          = LA_purpose_of_loan
              AND LNC_CATEGORY_SUFFIX        = trim(SUBSTR(la_court_name,1,4))
              AND LA_LOAN_TYPE               = '2'
              AND LA_ACCOUNT_STATUS         <> 'C'
              AND EXISTS
                (SELECT *
                FROM LOAN_ACCOUNTS B
                WHERE B.LA_ACCOUNT_NO BETWEEN to_number(A.LA_ACCOUNT_NO
                  ||'0001')
                AND to_number(A.LA_ACCOUNT_NO
                  ||'9999')
                AND B.LA_LOAN_TYPE      = '2'
                AND B.LA_ACCOUNT_STATUS = 'C'
                )
              AND NOT EXISTS
                (SELECT *
                FROM LOAN_ACCOUNTS C
                WHERE C.LA_ACCOUNT_NO BETWEEN to_number(A.LA_ACCOUNT_NO
                  ||'0001')
                AND to_number(A.LA_ACCOUNT_NO
                  ||'9999')
                AND C.LA_LOAN_TYPE       = '2'
                AND C.LA_ACCOUNT_STATUS != 'C'
                )
              AND LA_ACCOUNT_NO       = AO_ACCOUNT_NO
              AND la_date_of_advance IS NULL
              AND AO_CUSTOMER_ID      = to_number(db_customer_id)
              UNION ALL
              SELECT LA_CURRENCY_CODE,
                TO_CHAR(LA_ACCOUNT_NO),
                TO_CHAR(SUM(NVL(lab_principal,0)) * -1, '999999999990.99')
              FROM ACCOUNT_OWNERS,
                LOAN_ACCOUNTS,
                LOAN_ACCOUNT_BALANCES
              WHERE LAB_ACCOUNT_NO   = LA_ACCOUNT_NO
              AND LA_LOAN_TYPE      IN ('5', '6')
              AND LA_ACCOUNT_STATUS != 'C'
              AND LA_ACCOUNT_NO      = AO_ACCOUNT_NO
              AND AO_CUSTOMER_ID     = to_number(db_customer_id)
              GROUP BY LA_ACCOUNT_NO,
                LA_CURRENCY_CODE,
                LA_LOAN_TYPE
              UNION ALL
              SELECT LA_CURRENCY_CODE,
                TO_CHAR(LA_ACCOUNT_NO),
                TO_CHAR(0,'999999999990.99')
              FROM LOAN_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE LA_LOAN_TYPE    IN ('1', '3', '4')
              AND LA_ACCOUNT_STATUS != 'C'
              AND LA_MAX_SUB_ITEMS  IS NOT NULL
              AND LA_ACCOUNT_NO      = AO_ACCOUNT_NO
              AND AO_CUSTOMER_ID     = to_number(db_customer_id)
              GROUP BY LA_ACCOUNT_NO,
                LA_CURRENCY_CODE,
                LA_REMAINING_PRINCIPAL,
                LA_LOAN_TYPE
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(0)
              FROM ACCOUNT_OWNERS,
                UNIT_TRUST_ACCOUNTS
              WHERE UTA_ACCOUNT_STATUS <> 'C'
              AND AO_ACCOUNT_NO         = UTA_ACCOUNT_NO
              AND AO_CUSTOMER_ID        = to_number(db_customer_id)
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(0)
              FROM ACCOUNT_OWNERS,
                PHONE_BANKING_ACCOUNTS
              WHERE PBA_ACCOUNT_STATUS <> 'C'
              AND AO_ACCOUNT_NO         = PBA_ACCOUNT_NO
              AND AO_CUSTOMER_ID        = to_number(db_customer_id)
              UNION ALL
              SELECT CCA_CURRENCY_CODE,
                TO_CHAR(5000000000000000),
                TO_CHAR(SUM(DECODE(AO_OWNER_TYPE, 'OWN', NVL(CCA_CURRENT_BALANCE,0),0)), '999999999990.99')
              FROM
                (SELECT NVL(MAX(FAC_ALLOWABLE_FACILITY_AMT),0) cus_limit
                FROM FACILITIES
                WHERE FAC_FACILITY_TYPE IN ('CR', 'TC')
                AND FAC_CUSTOMER_ID      = to_number(db_customer_id)
                ),
                FACILITIES,
                CREDIT_CARD_ACCOUNTS,
                ACCOUNT_OWNERS,
                CUSTOMERS
              WHERE FAC_FACILITY_TYPE                 IN ('CR', 'TC')
              AND FAC_ACCOUNT_NO                       = CCA_ACCOUNT_NO
              AND NVL(CCA_BLOCK_CODE, '?') NOT        IN ('A', 'F', 'N', 'Y')
              AND NVL(CCA_CARDHOLDER_STATUS, '?') NOT IN ('3', '4', '8', '9')
              AND CCA_ACCOUNT_STATUS                  != 'C'
              AND AO_ACCOUNT_NO                        = CCA_ACCOUNT_NO
              AND AO_CUSTOMER_ID                       = CUS_CUSTOMER_ID
              AND AO_CUSTOMER_ID                       = to_number(db_customer_id)
              GROUP BY CCA_CURRENCY_CODE
              UNION ALL
              SELECT DECODE(acr_card_type,'04','RMB','14','RMB','HKD'),
                TO_CHAR(ACRA_ACCOUNT_NO),
                TO_CHAR(0)
              FROM ATM_CARDS a,
                ATM_CARD_RELATED_ACCOUNTS
              WHERE ACRA_ATM_CARD_ISSUE_NO  = ACR_ATM_CARD_ISSUE_NO
              AND ACRA_ATM_CARD_NO          = ACR_ATM_CARD_NO
              AND ACR_CUSTOMER_ID           = to_number(db_customer_id)
              AND ACRA_PRIMARY_AC_INDICATOR = 'Y'
              AND ACRA_ATM_CARD_ISSUE_NO    =
                (SELECT MAX(b.ACR_ATM_CARD_ISSUE_NO)
                FROM ATM_CARDS b
                WHERE b.ACR_ATM_CARD_NO = a.ACR_ATM_CARD_NO
                AND b.ACR_CUSTOMER_ID   = to_number(db_customer_id)
                )
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(AO_ACCOUNT_NO),
                TO_CHAR(0)
              FROM LG_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE LGAC_ACCOUNT_STATUS <> 'C'
              AND LGAC_ACCOUNT_NO        = AO_ACCOUNT_NO
              AND AO_CUSTOMER_ID         = to_number(db_customer_id)
              UNION ALL
              SELECT 'HKD',
                SUBSTR(MPC_SCHEME_NO,1,16),
                TO_CHAR(0)
              FROM MPF_CUSTOMERS,
                CUSTOMERS
              WHERE MPC_COUNTRY_ISSUED  = CUS_COUNTRY_ISSUED
              AND MPC_IDENTITY_REF_TYPE = CUS_IDENTITY_REF_TYPE
              AND MPC_IDENTITY_NO       = CUS_IDENTITY_NO
              AND db_customer_id       = to_number(db_customer_id)
              UNION ALL
              SELECT MAX(UNF_CURRENCY_CODE),
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM UNCOMMITTED_FACILITIES,
                UNCOMMITTED_DRAWS
              WHERE UNF_FACILITY_SERIAL_NO = UND_FACILITY_SERIAL_NO(+)
              AND UNF_STATUS               = 'R'
              AND (UNF_1st_CUSTOMER_ID     = to_number(db_customer_id)
              OR UNF_2nd_CUSTOMER_ID       = to_number(db_customer_id)
              OR UNF_3rd_CUSTOMER_ID       = to_number(db_customer_id)
              OR UNF_4th_CUSTOMER_ID       = to_number(db_customer_id)
              OR UNF_5th_CUSTOMER_ID       = to_number(db_customer_id)
              OR UND_DRAWER_REF_ID         = to_number(db_customer_id) )
              GROUP BY UNF_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM FX_FORWARD_FACILITIES,
                FX_FORWARD_DRAWS
              WHERE FFF_SERIAL_NO     = FFD_SERIAL_NO(+)
              AND FFF_STATUS          = 'R'
              AND ( FFF_CUSTOMER_ID_1 = to_number(db_customer_id)
              OR FFF_CUSTOMER_ID_2    = to_number(db_customer_id)
              OR FFF_CUSTOMER_ID_3    = to_number(db_customer_id)
              OR FFF_CUSTOMER_ID_4    = to_number(db_customer_id)
              OR FFF_CUSTOMER_ID_5    = to_number(db_customer_id)
              OR FFD_DRAWER_ID        = to_number(db_customer_id) )
              GROUP BY FFF_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM OVERSEAS_BRANCH_FACILITIES
              WHERE ( OBF_1ST_CUSTOMER_ID = to_number(db_customer_id)
              OR OBF_2ND_CUSTOMER_ID      = to_number(db_customer_id)
              OR OBF_3RD_CUSTOMER_ID      = to_number(db_customer_id)
              OR OBF_4TH_CUSTOMER_ID      = to_number(db_customer_id)
              OR OBF_5TH_CUSTOMER_ID      = to_number(db_customer_id) )
              AND OBF_STATUS              = 'R'
              GROUP BY OBF_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM TREASURY_PRODUCTS
              WHERE TRP_CUSTOMER_ID = to_number(db_customer_id)
              AND TRP_STATUS        = 'R'
              GROUP BY TRP_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM VISA_DISCOUNTS
              WHERE (VD_CUSTOMER_ID = to_number(db_customer_id)
              OR VD_GROUP_ID        = to_number(db_customer_id))
              AND VD_STATUS         = 'R'
              GROUP BY VD_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM APPROVED_NOT_DRAW_FACILITIES
              WHERE ( ANDF_CUSTOMER_ID_1 = to_number(db_customer_id)
              OR ANDF_CUSTOMER_ID_2      = to_number(db_customer_id)
              OR ANDF_CUSTOMER_ID_3      = to_number(db_customer_id)
              OR ANDF_CUSTOMER_ID_4      = to_number(db_customer_id)
              OR ANDF_CUSTOMER_ID_5      = to_number(db_customer_id)
              OR ANDF_GROUP_ID           = to_number(db_customer_id))
              AND ANDF_STATUS            = 'R'
              GROUP BY ANDF_STATUS
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(IBA_CUST_REF_NO),
                TO_CHAR(0)
              FROM IBANKING_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE AO_CUSTOMER_ID = to_number(db_customer_id)
              AND AO_ACCOUNT_NO    = IBA_CUST_REF_NO
              UNION ALL
              SELECT OLA_CURRENCY_CODE,
                TO_CHAR(OA_ACCOUNT_NO),
                TO_CHAR(-OLA_OUTSTANDING_PRINCIPAL,'999999999990.99')
              FROM OVERSEAS_LOAN_ACCOUNTS,
                OVERSEAS_ACCOUNTS,
                OVERSEAS_ACCOUNT_OWNERS
              WHERE OLA_FACILITY_TYPE = 'IL'
              AND OA_ACCOUNT_NO       = OLA_ACCOUNT_NO
              AND OA_ACCOUNT_STATUS  != 'C'
              AND OLA_ACCOUNT_NO      = OAO_ACCOUNT_NO
              AND OAO_CUSTOMER_ID     = to_number(db_customer_id)
              UNION ALL
              SELECT DAB_CURRENCY_CODE,
                TO_CHAR(DA_ORIGINAL_ACCOUNT_NO),
                TO_CHAR(0)
              FROM DEMAND_ACCOUNT_BALANCES,
                DEMAND_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE DA_ACCOUNT_TYPE     IN ('DBT','SUS', 'SCD')
              AND DA_ACCOUNT_STATUS     != 'C'
              AND DAB_ACCOUNT_ID         = DA_ACCOUNT_ID
              AND DA_ORIGINAL_ACCOUNT_NO = AO_ACCOUNT_NO
              AND AO_CUSTOMER_ID         = to_number(db_customer_id)
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(7000000000000000),
                TO_CHAR(0)
              FROM CHS_SECURITIES_ACCOUNTS,
                ACCOUNT_OWNERS
              WHERE AO_CUSTOMER_ID = to_number(db_customer_id)
              AND AO_ACCOUNT_NO    = CHSA_ACCOUNT_NO
              GROUP BY AO_CUSTOMER_ID
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM INTEREST_RATE_SWAP_FACILITIES
              WHERE ( IRSF_CUSTOMER_ID_1 = to_number(db_customer_id)
              OR IRSF_CUSTOMER_ID_2      = to_number(db_customer_id)
              OR IRSF_CUSTOMER_ID_3      = to_number(db_customer_id)
              OR IRSF_CUSTOMER_ID_4      = to_number(db_customer_id)
              OR IRSF_CUSTOMER_ID_5      = to_number(db_customer_id))
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9500000000000000),
                TO_CHAR(0)
              FROM LIFE_INSURANCE_CUSTOMERS
              WHERE LIS_OWNER_ID = to_number(db_customer_id)
              GROUP BY LIS_OWNER_ID
              UNION ALL
              SELECT 'HKD',
                TO_CHAR(9400000000000000),
                TO_CHAR(0)
              FROM NDF_FACILITIES,
                NDF_DRAWS
              WHERE NDF_SERIAL_NO    = NDD_SERIAL_NO(+)
              AND NDF_STATUS         = 'R'
              AND (NDF_CUSTOMER_ID_1 = to_number(db_customer_id)
              OR NDF_CUSTOMER_ID_2   = to_number(db_customer_id)
              OR NDF_CUSTOMER_ID_3   = to_number(db_customer_id)
              OR NDF_CUSTOMER_ID_4   = to_number(db_customer_id)
              OR NDF_CUSTOMER_ID_5   = to_number(db_customer_id)
              OR NDD_DRAWER_ID       = to_number(db_customer_id))
              GROUP BY NDF_STATUS
        UNION ALL
        SELECT UTF_CURRENCY_CODE,
        TO_CHAR(UTAB_ACCOUNT_NO),
        TO_CHAR(ROUND(NVL(SUM(UTAB_CLOSING_BALANCE * UTF_UNIT_PRICE * ERH_BID_RATE), 0), 2), '999999999990.99')
        FROM EXCHANGE_RATE_HISTORIES,
          EXCHANGE_RATES,
          UNIT_TRUST_FUNDS,
          UNIT_TRUST_ACCOUNT_BALANCES,
          ACCOUNT_OWNERS
        WHERE UTAB_ACCOUNT_NO         = AO_ACCOUNT_NO
        AND AO_CUSTOMER_ID            = db_customer_id
        AND UTAB_FUND_CODE            = UTF_FUND_CODE
        AND ER_CURRENCY_CODE          = UTF_CURRENCY_CODE
        AND ER_EXCHANGE_RATE_TYPE     = 'MEX'
        AND ER_CURRENCY_EXCH_SUB_TYPE = 'TT'
        AND ERH_EXCHANGE_RATE_CODE    = ER_EXCHANGE_RATE_CODE
        AND ERH_EFFECTIVE_TIMESTAMP   =
          (SELECT MAX(ERH_EFFECTIVE_TIMESTAMP)
          FROM EXCHANGE_RATE_HISTORIES
          WHERE ERH_EXCHANGE_RATE_CODE = ER_EXCHANGE_RATE_CODE
          AND ERH_EFFECTIVE_TIMESTAMP  < APP$BSNDT.GET_CURR_PROC_DATE + 1
          )
        GROUP BY UTF_CURRENCY_CODE, UTAB_ACCOUNT_NO
        HAVING UTF_CURRENCY_CODE='HKD'
              )
            )
        ) loop
      if rec.amt > 0 then
                total := total + ROUND5(rec.amt);
      end if;
        end loop;
        dbms_output.put_line('Total: ' || TO_CHAR(total, 'S000000000000.00'));
end;
/