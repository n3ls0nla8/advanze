[37mOPS$TEAM2@cdbdev> [0m@pkgb
Enter value for source_name: APP$EXCHRATE

TEXT
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
package body APP$EXCHRATE as
--
   BOOK            constant varchar2(1) := 'B';
   NOTE            constant varchar2(1) := 'N';
   TT              constant varchar2(1) := 'T';

/* =================================================================== */
   procedure GET_RATE ( currency     in varchar2,
                        rate_type    in varchar2,
                        sub_type     in varchar2,
                        online_batch in varchar2,
                        bid_rate     out number,
                        offer_rate   out number)
   is
        curr_proc_date      date;
        invalid_parm_OB     exception;
   begin
        if online_batch = 'O' then
           curr_proc_date := APP$ONLBSNDT.GET_CURR_PROC_DATE;
        elsif online_batch = 'B' then
           curr_proc_date := APP$BSNDT.GET_CURR_PROC_DATE;
        else
           raise invalid_parm_OB;
        end if;

        select ER_BID_RATE, ER_OFFER_RATE
        into bid_rate, offer_rate
        from EXCHANGE_RATES
        where ER_EXCHANGE_RATE_TYPE = rate_type
          and ER_CURRENCY_CODE = currency
          and ER_CURRENCY_EXCH_SUB_TYPE = sub_type
          and trunc(ER_EFFECTIVE_TIMESTAMP) <= trunc(curr_proc_date);
   exception
        when invalid_parm_OB then
            DBS$TRANSACTION.EXIT_WITH_APP_ERROR(7099, 'Invalid parameter "online_batch"');
        when no_data_found then
             DBS$ERRMSG.RETURN_APP_ERROR_MSG(2329);
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_RATE;
/* =================================================================== */
   procedure GET_TT_BID_RATE ( currency     in varchar2,
                               online_batch in varchar2,
                               bid_rate     out number)
   is
        var_offer_rate EXCHANGE_RATES.ER_OFFER_RATE%type;
   begin
        GET_RATE ( currency, 'MEX', 'TT', online_batch, bid_rate, var_offer_rate );
   exception
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_TT_BID_RATE;
/* =================================================================== */
   procedure GET_EXCHANGE_RATE ( p_ccy in varchar2,
                                 p_date in date,
                                 p_type in varchar2,
                                 p_rate out number )
   is
     cursor get_rate(p_ccy varchar2, p_date date) is
       select ERH_BID_RATE,
              ERH_OFFER_RATE
       from   EXCHANGE_RATE_HISTORIES,
              EXCHANGE_RATES
       where  ERH_EFFECTIVE_TIMESTAMP < p_date+1
       and    ERH_EXCHANGE_RATE_CODE = ER_EXCHANGE_RATE_CODE
       and    ER_EXCHANGE_RATE_TYPE = 'MEX'
       and    ER_CURRENCY_EXCH_SUB_TYPE = 'TT'
       and    ER_CURRENCY_CODE = p_ccy
       order by ERH_EFFECTIVE_TIMESTAMP desc;
       w_bid_rate number := null;
       w_offer_rate number := null;
   begin
     open get_rate(p_ccy, p_date);
     fetch get_rate into w_bid_rate, w_offer_rate;
     close get_rate;
     if p_type = BUY then p_rate := w_bid_rate;
     elsif p_type = SELL then p_rate := w_offer_rate;
     elsif p_type = MIDDLE then p_rate := (w_bid_rate+w_offer_rate)/2;
     else p_rate := null;
     end if;
   exception
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_EXCHANGE_RATE;
/* =================================================================== */
   function GET_FAC_LINE_RATE_R ( p_ccy in varchar2,
                                  p_date in date )
       return number is
     cursor get_rate(rate_type varchar2, p_ccy varchar2, p_date date) is
       select ERH_BID_RATE
       from   EXCHANGE_RATE_HISTORIES,
              EXCHANGE_RATES
       where  ERH_EFFECTIVE_TIMESTAMP < p_date+1
       and    ER_CURRENCY_CODE = p_ccy
       and    ( ( rate_type = TT
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'TT' )
                or
                ( rate_type = NOTE
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'NOTE' )
                or
                ( rate_type = BOOK
                  and ER_EXCHANGE_RATE_TYPE = 'BOOK' ) )
       and    ERH_EXCHANGE_RATE_CODE = ER_EXCHANGE_RATE_CODE
       order by ERH_EFFECTIVE_TIMESTAMP desc;

       w_bid_rate number;
       w_found    boolean;
   begin
     open get_rate(TT, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(NOTE, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(BOOK, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     raise no_data_found;

   end GET_FAC_LINE_RATE_R;
/* =================================================================== */
   function GET_FAC_LINE_RATE ( p_ccy in varchar2,
                                p_date in date )
       return number is
   begin
     return( GET_FAC_LINE_RATE_R( p_ccy , p_date ) );
   exception
        when no_data_found then
             DBS$ERRMSG.RETURN_APP_ERROR_MSG (2376);
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_FAC_LINE_RATE;


/* =================================================================== */
   function GET_LAB_EXCH_RATE_R ( p_ccy in varchar2,
                                  p_date in date )
       return number is
     cursor get_rate(rate_type varchar2, p_ccy varchar2, p_date date) is
       select ERH_BID_RATE
       from   EXCHANGE_RATE_HISTORIES,
              EXCHANGE_RATES
       where  ERH_EFFECTIVE_TIMESTAMP < p_date+1
       and    ER_CURRENCY_CODE = p_ccy
       and    ( ( rate_type = TT
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'TT' )
                or
                ( rate_type = NOTE
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'NOTE' )
                or
                ( rate_type = BOOK
                  and ER_EXCHANGE_RATE_TYPE = 'BOOK' ) )
       and    ERH_EXCHANGE_RATE_CODE = ER_EXCHANGE_RATE_CODE
       order by ERH_EFFECTIVE_TIMESTAMP desc;

       w_bid_rate number;
       w_found    boolean;
   begin
     open get_rate(TT, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(NOTE, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(BOOK, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     raise no_data_found;

   end GET_LAB_EXCH_RATE_R;
/* =================================================================== */
   function GET_LAB_EXCH_RATE ( p_ccy in varchar2,
                                p_date in date )
       return number is
   begin
     return( GET_LAB_EXCH_RATE_R( p_ccy, p_date ) );
   exception
        when no_data_found then
             DBS$ERRMSG.RETURN_APP_ERROR_MSG (2376);
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_LAB_EXCH_RATE;


/* =================================================================== */
   function GET_TNB_EXCH_RATE_R ( p_ccy in varchar2,
                                  p_date in date )
       return number is
     cursor get_rate(rate_type varchar2, p_ccy varchar2, p_date date) is
       select ERH_BID_RATE
       from   EXCHANGE_RATE_HISTORIES,
              EXCHANGE_RATES
       where  ERH_EFFECTIVE_TIMESTAMP < p_date+1
       and    ER_CURRENCY_CODE = p_ccy
       and    ( ( rate_type = TT
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'TT' )
                or
                ( rate_type = NOTE
                  and ER_EXCHANGE_RATE_TYPE = 'MEX'
                  and ER_CURRENCY_EXCH_SUB_TYPE = 'NOTE' )
                or
                ( rate_type = BOOK
                  and ER_EXCHANGE_RATE_TYPE = 'BOOK' ) )
       and    ERH_EXCHANGE_RATE_CODE = ER_EXCHANGE_RATE_CODE
       order by ERH_EFFECTIVE_TIMESTAMP desc;

       w_bid_rate number;
       w_found    boolean;
   begin
     open get_rate(TT, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(NOTE, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     open get_rate(BOOK, p_ccy, p_date);
     fetch get_rate into w_bid_rate;
     w_found := get_rate%found;
     close get_rate;
     if w_found then
        return(w_bid_rate);
     end if;

     raise no_data_found;

   end GET_TNB_EXCH_RATE_R;
/* =================================================================== */
   function GET_TNB_EXCH_RATE ( p_ccy in varchar2,
                                p_date in date )
       return number is
   begin
     return( GET_TNB_EXCH_RATE_R( p_ccy, p_date ) );
   exception
        when no_data_found then
             DBS$ERRMSG.RETURN_APP_ERROR_MSG (2376);
        when others then
             DBS$ERRMSG.RETURN_DB_ERROR_MSG;
   end GET_TNB_EXCH_RATE;

/* =================================================================== */
--
end APP$EXCHRATE;

287 rows selected.

[37mOPS$TEAM2@cdbdev> [0m
